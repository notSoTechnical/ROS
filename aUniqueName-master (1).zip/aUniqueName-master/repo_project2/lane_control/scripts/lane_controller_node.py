#!/usr/bin/env python
import math
import time
import numpy as np
import rospy
from duckietown_msgs.msg import Twist2DStamped, LanePose, WheelsCmdStamped
import time
import numpy as np

class pid_controller():
    def __init__(self):
        self.p = 3
        self.i = 0
        self.d = 0
        self.now = rospy.get_time()
        self.t_change = 0
        self.error = 0
        self.error_sum = 0
        self.d_error = 0
        self.op = 0
        self.last_error = 0
        self.last_time = 0
    def getop(self,ip):
        self.now = rospy.get_time()
        self.t_change = self.now - self.last_time
        self.error = 0 - ip
        self.error_sum += self.t_change*self.error
        self.d_error = (self.error-self.last_error)/self.t_change
        self.op = (self.p*self.error) + (self.i*self.error_sum)+ (self.d*self.d_error)
        self.last_error = self.error
        self.last_time = self.now
        return self.op
class lane_pose_readings():
    def __init__(self):
        self.d_est = 0
        self.phi_est = 0
        self.d_ref = 0
        self.phi_ref = 0
        self.v_ref = 0
        self.sub_lane_reading = rospy.Subscriber("~lane_pose", LanePose, self.PoseHandling, queue_size=1)
    def PoseHandling(self,input_pose_msg):
        self.d_est = input_pose_msg.d
        self.phi_est = input_pose_msg.phi
        self.d_ref = input_pose_msg.d_ref
        self.phi_ref = input_pose_msg.phi_ref
        self.v_ref = input_pose_msg.v_ref

if __name__ == '__main__':
    rospy.init_node('lane_controller_node', anonymous=True)
    pub = rospy.Publisher('~car_cmd', Twist2DStamped, queue_size=1)    
    lpr = lane_pose_readings()
    pc = pid_controller()
    rate = rospy.Rate(10) # 10hz
    t_start = rospy.get_time()
    while not rospy.is_shutdown():
        t = rospy.get_time()
        msg = Twist2DStamped()
        msg.v = 0.3
        msg.omega = pc.getop(lpr.d_est)+pc.getop(lpr.phi_est)
        print("\n v = ",msg.v," omega = ",msg.omega," \n")
        pub.publish(msg)
        rate.sleep()



