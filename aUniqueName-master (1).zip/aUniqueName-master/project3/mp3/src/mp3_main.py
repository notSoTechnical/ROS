#!/usr/bin/env python
import math
import time
import numpy as np
import rospy
from sensor_msgs.msg import CompressedImage, Image
import time
from color_and_line import lane_filter
import cv2
from cv_bridge import CvBridge, CvBridgeError

# >>> cmprsmsg = br.cv2_to_compressed_imgmsg(im)  # Convert the image to a compress message
# >>> im22 = br.compressed_imgmsg_to_cv2(msg) # Convert the compress message to a new image

class Transformer():
        def __init__(self):
                self.bridge = CvBridge()
                #self.white_transform = [np.array(x, np.uint8) for x in [[0,140,100], [15, 255,255]] ]
                #self.yellow_transform = [np.array(x, np.uint8) for x in [[165,140,100], [180, 255, 255]] ]
                self.sub = rospy.Subscriber("/duckiebutt/image_transformer_node/corrected_image/compressed", CompressedImage, self.Transform_func, queue_size=1)
                self.pub_white = rospy.Publisher('mp3_white_transform', Image, queue_size=1)
                self.pub_yellow = rospy.Publisher('mp3_yellow_transform', Image, queue_size=1)
        
	def Transform_func(self,Compressed_image):
                np_arr = np.fromstring(Compressed_image.data, np.uint8)
                image_cv = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                white_transform, yellow_transform = lane_filter(image_cv)
                try:

                        self.pub_white.publish(self.bridge.cv2_to_imgmsg(white_transform, "bgr8"))
                        self.pub_yellow.publish(self.bridge.cv2_to_imgmsg(yellow_transform, "bgr8"))
                except TypeError as e:
                        print("Errors ",e)

if __name__ == '__main__':
        rospy.init_node('mp3_main', anonymous=True)
        rate = rospy.Rate(10) # 10hz
        t = Transformer()
        while not rospy.is_shutdown():
                rate.sleep()

