#!/usr/bin/env python
import sys
import cv2
import numpy as np

def get_lines(original_image, filtered_image):
    r_res = 1
    theta_res = np.pi/180
    thresh = 17 #10 is best
    min_length = 1
    max_gap = 4
    lines = cv2.HoughLinesP(filtered_image, r_res, theta_res, thresh, np.empty(1), min_length, max_gap)
    output = np.copy(original_image)
    if lines is not None:
        for i in range(len(lines)):
            l = lines[i][0]
            cv2.line(output, (l[0],l[1]), (l[2],l[3]), (0,0,255), 3, cv2.LINE_AA)
    return output

def lane_filter(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    
    # Filter for only white pixels. Experiment with values as needed
    white_filter = cv2.inRange(hsv, (0,0,210), (255,60,255))
    
    # Filter for only yellow pixels. Experiment with values as needed
    yellow_filter = cv2.inRange(hsv, (30,100,100), (140,255,255))#(20,100,100), (30,255,255))
    
    # Create a kernel to dilate the image. 
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
    
    # Dilate both the white and yellow images. 
    white_dilate = cv2.dilate(white_filter, kernel)
    yellow_dilate = cv2.dilate(yellow_filter, kernel)
    
    # Perform edge detection on the original image. 
    edges = cv2.Canny(image, 100, 300, apertureSize=3)
    
    # Use the edges to refine the lines in both white and yellow images
    white_edges = cv2.bitwise_and(white_dilate, edges)
    yellow_edges = cv2.bitwise_and(yellow_dilate, edges)
    
    white_output = get_lines(image, white_edges)
    yellow_output = get_lines(image, yellow_edges)
    
    return white_output, yellow_output
